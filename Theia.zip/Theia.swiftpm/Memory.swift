import SwiftUI
import Subsonic

struct Memory: View {
    private static let initialColumns = 2
    @State var selection: Int? = nil
    @State private var selectedSymbolName: String?
    @State private var numColumns = initialColumns
    @State private var gridColumns = Array(repeating: GridItem(.flexible()), count: initialColumns)
    var symbolNames = [
        "Splash",
        "Ring",
        "Cock-a-doodle-do",
        "Buzz",
        "Tick",
        "Click",
    ]
    var columnsText: String {
        numColumns > 1 ? "\(numColumns) Columns" : "1 Column"
    }
    
    var body: some View {
        VStack {
            ScrollView {
                Text("Tap on each letter to hear a sound and memorize the pairs. Click 'I'm ready' when you are confident!").padding()
                LazyVGrid(columns: gridColumns) {
                    ForEach(symbolNames, id: \.self) { name in
                        Button {
                            play(sound: "\(name).mp3")
                        } label: {
                            Image(name)
                                .resizable()
                                .scaledToFit()
                                .padding()
                        }
                    }
                    .padding()
                }
                .buttonStyle(.plain)
                .navigationBarTitle("Memory Game")  
                .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
}
    
struct Quiz: View {
    @State var selectedSymbol = "B"
    @State private var symbolNames = [
        "B",
        "I",
        "G",
        "S",
        "U",
        "R",
    ]
    @State private var showingAlert = false
    @State var buttonMsg = "Check"
    func isCorrect(sound: String) -> String {
        showingAlert = false
        buttonMsg = "Continue"
        return selectedSymbol == "R" ? "You are correct!": "Try again!" 
    }
    @State var selection: Int? = nil
    var body: some View {
        Text("Drag the selector above the 'Check' button to indicate your choice.")
        Text("What letter goes with this sound?")
        Button {
            play(sound: "Click.mp3")
        } label: {
            Text("Play me ⏯")
        }
        Picker("sym", selection: $selectedSymbol, content: {
            ForEach(symbolNames, id: \.self, content: { sym in Text(sym)})
        }).pickerStyle(WheelPickerStyle())
        
        Button("Check") {
            showingAlert = true
        }.alert(isPresented: $showingAlert) {
            Alert(title: Text(isCorrect(sound: selectedSymbol))
                  , dismissButton: .default(Text("Got it!")))
        }.padding()
            .background(Color.purple)
            .foregroundColor(Color.white)
            .cornerRadius(10)
    }
}

struct Memory_Previews: PreviewProvider {
    static var previews: some View {
        Memory()
    }
}
