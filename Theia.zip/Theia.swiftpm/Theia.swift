import SwiftUI

@main
struct Theia: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
