import SwiftUI
import MobileCoreServices

struct CategoryView: View {
        @State var selection: Int? = nil
        var correctCounter: Int = 0
        var columns = Array(repeating: GridItem(.flexible(), spacing: 15), count: 2)
        @ObservedObject var delegate = ImgData()
        var body: some View {
            VStack(spacing: 15) {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(delegate.totalImages) { image in Image(image.image)
                                .resizable()
                                .scaledToFit()
                                .onDrag {
                                    NSItemProvider(item: .some(URL(string: image.image)! as NSSecureCoding), typeIdentifier: String(kUTTypeURL))
                                }
                        }
                        /*Button("Check") {
                            print("ya")
                            showAlert = true
                        }.alert("Nice!", isPresented: $showAlert) {
                        }*/
                    }
                    .padding(.all)
                }
                ZStack {
                    if delegate.selectedImages.isEmpty {
                        Text("Drop All Graphemes (letters + numbers) Here!")
                            .fontWeight(.bold)
                            .foregroundColor(.accentColor)
                            .multilineTextAlignment(.center)
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(delegate.selectedImages, id: \.image) { image in 
                                if image.image != "" {
                                    ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
                                        Image(image.image)
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(15)
                                        Button(action: {
                                            withAnimation(.easeOut) {
                                                self.delegate.selectedImages.removeAll {
                                                    (check) -> Bool in
                                                    if check.image == image.image{return true}
                                                    else{return false}
                                                }
                                            }
                                        }) {
                                            Image(systemName: "xmark")
                                                .foregroundColor(.white)
                                                .padding(10)
                                                .background(Color.black)
                                                .clipShape(Circle())
                                        }
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .padding(.bottom, UIApplication.shared.windows.first?.safeAreaInsets.bottom)
                .padding(.top, 10)
                .frame(height: delegate.selectedImages.isEmpty ? 100 : nil)
                .contentShape(Rectangle())
                .background(Color.white)
                .onDrop(of: [String(kUTTypeURL)], delegate: delegate)
            }
            .background(Color.black.opacity(0.05))
            .edgesIgnoringSafeArea(.bottom)
        }
    }
    class ImgData: ObservableObject, DropDelegate {
        @Published var totalImages: [Img] = [
            Img(id: 0, image: "1W"),
            Img(id: 1, image: "8"),
            Img(id: 2, image: "2W"),
            Img(id: 3, image: "3D"),
            Img(id: 4, image: "7"),
            Img(id: 5, image: "4C"),
            Img(id: 6, image: "52"),
            Img(id: 7, image: "10"),
            Img(id: 8, image: "9"),
            Img(id: 9, image: "62"),
        ]
        @Published var selectedImages: [Img] = []
        
        var correctCounter: Int = 0
        func performDrop(info: DropInfo) -> Bool {
            for provider in info.itemProviders(for: [String(kUTTypeURL)]) {
                if provider.canLoadObject(ofClass: URL.self) {
                    print("url loaded")
                    let _ = provider.loadObject(ofClass: URL.self) { (url, err) in
                        print(url!)
                        if "\(url!)" == "1W" || "\(url!)" == "2W" || "\(url!)" == "3D" || "\(url!)" == "4C" || "\(url!)" == "52" || "\(url!)" == "62" {
                            self.correctCounter += 1
                            print(self.correctCounter)
                            //Alert(title: Text("Nice!"), message: Text("Click next"), dismissButton: .default(Text("Cool")))
                        }
                        let status = self.selectedImages.contains {
                            (check) -> Bool in
                            if check.image == "\(url!)" {
                                return true
                            }
                            else{return false}
                        }
                        if !status {
                            DispatchQueue.main.async {
                                withAnimation(.easeOut) {
                                    self.selectedImages.append(Img(id: self.selectedImages.count, image: "\(url!)"))
                                }
                            }
                            if self.correctCounter == 6 {
                                print("yes show alert pls")
                                //return self.showAlert = true
                            }
                            
                        }
                    }
                } else {
                    print("cannot load")
                }
            }
            return true
        }
    }
    
    struct Img: Identifiable {
        var id: Int
        var image: String
    }
