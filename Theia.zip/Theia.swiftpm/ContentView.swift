import SwiftUI
import AVKit

struct ContentView: View {
    struct PlayerView: UIViewRepresentable {
        func updateUIView(_ uiView: UIView, context: UIViewRepresentableContext<PlayerView>) {
        }
        func makeUIView(context: Context) -> UIView {
            return LoopingPlayerUIView(frame: .zero)
        }
    }
    class LoopingPlayerUIView: UIView {
        private let playerLayer = AVPlayerLayer()
        private var playerLooper: AVPlayerLooper?
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        override init(frame: CGRect) {
            super.init(frame: frame)
            let fileUrl = Bundle.main.url(forResource: "MeshGradientBkg", withExtension: "mov")!
            let asset = AVAsset(url: fileUrl)
            let item = AVPlayerItem(asset: asset)
            let player = AVQueuePlayer()
            playerLayer.player = player
            playerLayer.videoGravity = .resizeAspectFill
            layer.addSublayer(playerLayer)
            playerLooper = AVPlayerLooper(player: player, templateItem: item)
            player.play()
        }
        override func layoutSubviews() {
            super.layoutSubviews()
            playerLayer.frame = bounds
        }
    }
    
    var body: some View {
        NavigationView {
            PlayerView()
            .edgesIgnoringSafeArea(.all) 
            .overlay(ContentOverlay())
            Spacer()
        }
    }

struct ContentOverlay: View {
    var body: some View {
        VStack() {
            Text("Welcome to Theia!✨")
                .font(.largeTitle)
                .fontWeight(.black)
                .multilineTextAlignment(.center)
                .padding()
            Image("ColorHearing")
                .resizable()
                .scaledToFit()
            NavigationLink(destination: SecondView()) {
                Text("Let's begin!!")
                    .padding()
                    .background(Color.purple)
                    .foregroundColor(Color.white)
                    .cornerRadius(10)
            }
        }
    }
}

struct SecondView: View {
    var body: some View {
        VStack(spacing: 30) {
            Text("You will be learning 📝 and stepping into the shoes 👞 of a synesthete, who has a neurological phenomenon 🧠 called synesthesia ⚡️, or joined sensation. Are you ready to play ▶️?")
                .padding()
                .multilineTextAlignment(.center)
            NavigationLink(destination: ThirdView()) {
                Text("Never been more ready!")
                    .padding()
                    .background(Color.purple)
                    .foregroundColor(Color.white)
                    .cornerRadius(10)
            }
        }
    }
}

struct ThirdView: View {
    var body: some View {
        CategoryView()
            .navigationTitle("Drag all graphemes into the box!")
            .navigationBarTitleDisplayMode(.inline)
        NavigationLink(destination: FourthView()) {
            Text("Next")
                .padding()
                .background(Color.purple)
                .foregroundColor(Color.white)
                .cornerRadius(10)
        }
    }
}

struct FourthView: View {
    var body: some View {
        Text(" Nice work! Your brain 🧠 is smart enough to separate shapes with graphemes, or the smallest ▫️ language units that contain meaning. Have you ever associated a color 🎨 with a sound 🔊? A flavor 👅 with a physical feeling 👆🏼? In other words, has a stimulus 🙌🏼 triggered an unrelated 🙈, automatic, and involuntary 🙉 sensory experience 👄? Let’s play a memory game 🧩 to find out.")
            .padding()
            .multilineTextAlignment(.center)
        NavigationLink(destination: FifthView()) {
            Text("I want to try!")
                .padding()
                .background(Color.purple)
                .foregroundColor(Color.white)
                .cornerRadius(10)
        }
    }
}
    
struct FifthView: View {
    var body: some View {
        Memory()
        NavigationLink(destination: SixthView()) {
            Text("I'm ready!") 
                .padding()
                .background(Color.purple)
                .foregroundColor(Color.white)
                .cornerRadius(10)
        }
    }
}
struct SixthView: View {
    var body: some View {
            Quiz()
            NavigationLink(destination: SeventhView()) {
                Text("Let's keep going!")
                    .padding()
                    .background(Color.purple)
                    .foregroundColor(Color.white)
                    .cornerRadius(10)
            }
        }
    }
    
struct SeventhView: View {
    var body: some View {
        Text("Synesthesia is pretty rare, in fact, only 1️⃣ in 2000 people have it. Synesthesia is pretty cool 😎, it may enhance creativity 🖊️! In fact, more artists 👩‍🎨 and writers ✍️ are synesthetes. While there are inheritable genes 🧬 with hyperconnecting brain neurons 🧠, there is evidence 🧐 that synesthesia can be learned 📖 by bridging🌉 2️⃣ categories, thereby forming new cognitive ⚙️ pathways. This is very similar to learning 🖌 a new vocabulary, by linking 🔗 a word ✏️ with its definition 📓. Lastly, you can learn 🖍 about some more fun facts!")
            .padding()
            .multilineTextAlignment(.center)
        NavigationLink(destination: EighthView()) {
            Text("Ooo I want to know more!")
                .padding()
                .background(Color.purple)
                .foregroundColor(Color.white)
                .cornerRadius(10)
        }
    }
}

struct EighthView: View {
    var body: some View {
        FunFactsView()
        NavigationLink(destination: NinthView()) {
            Text("I'm done!")
                .padding()
                .background(Color.purple)
                .foregroundColor(Color.white)
                .cornerRadius(10)
        }
    }
}

struct NinthView: View {
    var body: some View {
        PlayerView()
            .edgesIgnoringSafeArea(.all) 
            .overlay(NinthOverlay())
        Spacer()
        }
}

struct NinthOverlay: View {
    var body: some View {
        VStack {
            Text("Thanks for playing, hope you learned a thing or two about synesthesia!")
            .font(.title)
            .fontWeight(.bold)
            .multilineTextAlignment(.center)
            .padding()
            Text("Made with ❤️ by Audrey Wang")
                .font(.caption)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
        Image("Neuron")
            .resizable()
            .scaledToFit()
        }
    }
}
}
