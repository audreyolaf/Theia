import Foundation
import SwiftUI

struct Info {
    let funFacts: [String]
}

let information = Info(
    funFacts: [
        "There are 💯-200 variants of synesthesia.",
        "Color🌈-graphemic (letters) 🔤 and color 🟧-auditory 👂🏼 are the most common forms of synesthesia.",
        "The least common type of synesthesia is lexical 🈶-gustatory 👅, which links words and tastes 👅.",
        "Synesthesia is unrelated 🚫 to misophonia, or emotional reactions 😮 to sounds 🔉.",
        "Hallucination 💭, or perceiving something without a stimulus, is not the same as synesthesia.",
        "Frisson, or musical 🎵 chills, is not caused by synesthesia.",
        "Synesthetes might make up 4️⃣% of the population.",
        "Some synesthetes get overwhelmed by sensory overload 😵‍💫.",
        "Experts do not know what causes synesthesia, but if we did, it might explain 🔑 some mysteries 👁️‍🗨️ in human consciousness.",
        "Women 👩🏽 are more likely than men 👨🏻‍ to end up with synesthesia.",
        "Many synesthetes use their left hands 🤛 more than their right hands 🤜.",
        "Synesthesia runs in the blood 🩸. 40% of synesthetes have a relative 👥 with the same condition.",
        "A gene 🧬 in chromosome 16 may contribute to grapheme #️⃣-color synesthesia, or letter/number and color association 🖇️.",
    ]
)
