import SwiftUI

struct FunFactsView: View {
    @State private var funFact = ""
    var body: some View {
        VStack {
            Text("Fun Facts")
                .font(.largeTitle)
                .fontWeight(.bold)
            Image(systemName: "wand.and.stars.inverse")
            Text(funFact)
                .padding()
                .font(.title3)
                .frame(minHeight: 300)
                .multilineTextAlignment(.center)
            Button("Click here to generate fun facts!") {
                funFact = information.funFacts.randomElement()!
            }
        }
        .padding()
    }
}

struct FunFactsView_Previews: PreviewProvider {
    static var previews: some View {
        FunFactsView()
    }
}
